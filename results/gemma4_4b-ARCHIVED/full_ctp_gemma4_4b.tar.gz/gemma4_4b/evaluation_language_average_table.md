# Model: gemma4_4b

| variant | guarani_average | guarani_gain_base | english_average | english_gain_base | spanish_average | spanish_gain_base |
| --- | --- | --- | --- | --- | --- | --- |
| base | 14.38 | -- | 47.20 | -- | 46.55 | -- |
| full_C1_kuatia | 19.92 | +5.53 | 46.53 | -0.67 | 47.39 | +0.83 |
| full_C2_kuatia_no_synthetic | 18.61 | +4.23 | 46.16 | -1.04 | 46.21 | -0.35 |
| full_C3_kuatia_es20 | 18.91 | +4.52 | 46.27 | -0.93 | 46.61 | +0.06 |
| full_C4_kuatia_no_synthetic_es20 | 19.18 | +4.80 | 46.90 | -0.30 | 47.48 | +0.93 |
| full_C5_kuatia_en20 | 21.48 | +7.09 | 47.93 | +0.73 | 47.92 | +1.36 |
| full_C6_kuatia_no_synthetic_en20 | 21.83 | +7.45 | 48.94 | +1.74 | 48.26 | +1.70 |
| full_C7_kuatia_es10_en10 | 22.23 | +7.85 | 48.19 | +0.99 | 48.61 | +2.06 |
| full_C8_kuatia_no_synthetic_es10_en10 | 16.62 | +2.23 | 45.98 | -1.22 | 45.70 | -0.85 |
